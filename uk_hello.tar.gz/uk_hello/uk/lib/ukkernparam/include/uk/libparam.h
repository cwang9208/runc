/* SPDX-License-Identifier: BSD-3-Clause */
/*
 * Authors: Sharan Santhanam <sharan.santhanam@neclab.eu>
 *
 *
 * Copyright (c) 2018, NEC Europe Ltd., NEC Corporation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * THIS HEADER MAY NOT BE EXTRACTED OR MODIFIED IN ANY WAY.
 */
#ifndef __UK_KERNPARAM_H
#define __UK_KERNPARAM_H

#include <uk/arch/types.h>
#include <uk/essentials.h>
#include <uk/list.h>
#include <uk/print.h>

/**
 * Section name suffices
 */
#define LIB_KERNPARAM_SECTION	uk_kern_arg
#define LIB_PARAM_SUFFIX	__lib_param
#define LIB_NAME_SUFFIX		__lib_strrodata
#define LIB_PARAMVAR_PREFIX	_lib_param_
#define LIB_NAMEVAR_PREFIX	_lib_name_

#define PARAM_SECTION_SUFFIX	__param_arg
#define PARAM_NAME_SUFFIX	__param_strrodata
#define PARAM_PARAMVAR_PREFIX	_param_param_
#define PARAM_NAMEVAR_PREFIX	_param_name_

#define PARAM_SIGN_SHIFT        (7)
#define PARAM_SIGN_MASK		(0x1)
#define PARAM_SIZE_SHIFT	(0x0)
#define PARAM_SIZE_MASK         (0x7F)
#define PARAM_TYPE(size, sign)  (((__u8) (sign & PARAM_SIGN_MASK)) <<     \
						PARAM_SIGN_SHIFT) |       \
				(((__u8) (size & PARAM_SIZE_MASK)) <<     \
						PARAM_SIZE_SHIFT)

#define __stringify(x)				#x
#define __stringconcat(x, y)			x##y

/**
 * Primitive types
 */
#define _LIB_PARAM___s8		PARAM_TYPE(sizeof(__s8), 1)
#define _LIB_PARAM_char		_LIB_PARAM___s8
#define _LIB_PARAM___u8		PARAM_TYPE(sizeof(__u8), 0)
#define _LIB_PARAM___s16	PARAM_TYPE(sizeof(__s16), 1)
#define _LIB_PARAM___u16	PARAM_TYPE(sizeof(__u16), 0)
#define _LIB_PARAM___s32	PARAM_TYPE(sizeof(__s32), 1)
#define _LIB_PARAM_int		_LIB_PARAM___s32
#define _LIB_PARAM___u32	PARAM_TYPE(sizeof(__u32), 0)
#define _LIB_PARAM___s64	PARAM_TYPE(sizeof(__s64), 1)
#define _LIB_PARAM___u64	PARAM_TYPE(sizeof(__u64), 0)

struct uk_param {
	/* The name of the param */
	const char *name;
	/* Type information for the param */
	__u8 param_type;
	/* Type information for the variable size param */
	__u8 param_size;
	/* Define a reference to location of the parameter */
	__uptr addr;
};

struct uk_lib_section {
	/* Library name */
	const char *lib_name;
	/* Section header of the uk_param args */
	struct uk_param *sec_addr_start;
	/* Length of the section */
	__u32	len;
	UK_TAILQ_ENTRY(struct uk_lib_section) next;
};

/**
 * Parse through the kernel parameter
 * @param progname
 *	The application name
 * @param argc
 *	The number of arguments
 * @param argv
 *	Reference to the command line arguments
 * @return
 *	On success, return the number of argument parsed.
 *	On Failure, return the error code.
 */
int uk_kernparam_parse(const char *progname, int argc, char **argv);

/**
 * Register the library containing kernel parameter.
 *
 * @param lib_sec
 *	A reference to the uk_lib_section.
 */
void _uk_kernparam_lib_add(struct uk_lib_section *lib_sec);

/**
 * Macros to configure library.
 */
#define _SECTION_START(name)	__stringconcat(__start_,name)
#define _SECTION_STOP(name)	__stringconcat(__stop_,name)

/**
 * Create a section name.
 * @param libname
 *	The library name
 * @param section
 *	The section suffix for the library
 */
#define _LIB_PARAM_SECTION_NAME(libname, section_name)		\
			__stringconcat(libname, section_name)

/**
 * Add a section attribute.
 * @param section_name
 *	The name of the section.
 */
#define _LIB_PARAM_SECTION_ADD(section_name, align_type)		\
			__attribute__ ((used,				\
					section(			\
					__stringify(section_name)),	\
					aligned(sizeof(align_type))	\
				      ))
/**
 * Create a constructor name.
 * @param libname
 *	The library name.
 * @param suffix
 *	The suffix appended to the library name.
 */
#define _LIB_UK_CONSTRUCT_NAME(libname, suffix)			\
		libname##_##suffix

/**
 * Create a variable name
 * @param prefix
 *	The prefix to the variable name.
 * @param name
 *	
 */
#define _LIB_VARNAME_SET(prefix, name)				\
			__stringconcat(prefix, name)

/**
 * Import the section header.
 * @param libname
 *	The library name.
 */
#define _LIB_IMPORT_SECTION_PARAMS(libname, section_suffix)		\
	extern char *_SECTION_START(					\
			_LIB_PARAM_SECTION_NAME(libname,		\
						section_suffix));	\
	extern char *_SECTION_STOP(					\
			_LIB_PARAM_SECTION_NAME(libname,		\
						section_suffix));	\

/**
 * Create a library name variable and uk_lib_section for each library.
 * @param libname
 *	The library name.
 */
#define _LIB_SECTION_CREATE(section, libname)				\
	static const _LIB_PARAM_SECTION_ADD(				\
			_LIB_PARAM_SECTION_NAME(section,		\
						LIB_NAME_SUFFIX),	\
						char)			\
		char _LIB_VARNAME_SET(LIB_NAMEVAR_PREFIX,libname)[] =	\
						__stringify(libname);	\
	static _LIB_PARAM_SECTION_ADD(					\
			_LIB_PARAM_SECTION_NAME(section,		\
						LIB_PARAM_SUFFIX),	\
						void *)			\
		struct uk_lib_section					\
			_LIB_VARNAME_SET(LIB_PARAMVAR_PREFIX,libname) = \
			{ .lib_name = __NULL,				\
			  .sec_addr_start = __NULL, .len = 0		\
			};

#define _LIB_UK_CONSTRUCT_CREATE(libname)				\
	static void __constructor_prio(101)				\
	_LIB_UK_CONSTRUCT_NAME(libname,process_arg)(void)		\
	{								\
		int len = (__uptr) &_SECTION_STOP(			\
				_LIB_PARAM_SECTION_NAME(		\
					libname, PARAM_SECTION_SUFFIX)	\
					) -				\
			  (__uptr) &_SECTION_START(			\
				_LIB_PARAM_SECTION_NAME(		\
					libname, PARAM_SECTION_SUFFIX)	\
					 );				\
		uk_pr_debug("inside constructor %s--%d\n",		\
			    __func__, len);				\
		if (len > 0) {						\
			_LIB_VARNAME_SET(LIB_PARAMVAR_PREFIX, libname).	\
					sec_addr_start =		\
						(struct uk_param *)	\
						&_SECTION_START(	\
						_LIB_PARAM_SECTION_NAME(\
						libname,		\
						PARAM_SECTION_SUFFIX));	\
			_LIB_VARNAME_SET(LIB_PARAMVAR_PREFIX, libname).	\
						len=	len;		\
			_LIB_VARNAME_SET(LIB_PARAMVAR_PREFIX, libname).	\
						lib_name=		\
						&_LIB_VARNAME_SET(	\
						LIB_NAMEVAR_PREFIX,	\
						libname)[0];		\
			_uk_kernparam_lib_add(			\
						&_LIB_VARNAME_SET(	\
						LIB_PARAMVAR_PREFIX,	\
						libname)		\
						);			\
		}							\
	}

#define _LIB_UK_CONSTRUCT_INIT(libname)					\
		_LIB_IMPORT_SECTION_PARAMS(libname,			\
					   PARAM_SECTION_SUFFIX)	\
		_LIB_SECTION_CREATE(LIB_KERNPARAM_SECTION,libname)	\
		_LIB_UK_CONSTRUCT_CREATE(libname)


/**
 * Create a constructor to fill in the parameter.
 */
#ifdef UK_LIBPARAM_PREFIX
	_LIB_UK_CONSTRUCT_INIT(UK_LIBPARAM_PREFIX)
#endif /* UK_LIBPARAM_PREFIX */

#define _LIB_PARAM_STRING(libname, name)			\
			libname.name

#define _LIB_PARAM_NAME_SET(name, value)				\
	static const							\
	_LIB_PARAM_SECTION_ADD(						\
				_LIB_PARAM_SECTION_NAME(		\
						UK_LIBPARAM_PREFIX,	\
						PARAM_NAME_SUFFIX),	\
						char			\
			      )						\
	char _LIB_VARNAME_SET(PARAM_NAMEVAR_PREFIX,name)[] =		\
						__stringify(value)

#define _LIB_UK_PARAM_SET(param_name, type, cnt)			\
	static const							\
	_LIB_PARAM_SECTION_ADD(						\
				_LIB_PARAM_SECTION_NAME(		\
						UK_LIBPARAM_PREFIX,	\
						PARAM_SECTION_SUFFIX),	\
						void *			\
			      )						\
	struct uk_param _LIB_VARNAME_SET(PARAM_SECTION_SUFFIX,		\
				       param_name) = {			\
		.name = &_LIB_VARNAME_SET(PARAM_NAMEVAR_PREFIX,		\
					 param_name)[0],		\
		.param_type = _LIB_PARAM_##type,			\
		.param_size = cnt,					\
		.addr       = (__uptr) &param_name,			\
	}

/**
 * Declare a library param.
 * @param name
 *	The name of the library param.
 * @param type
 *	The type of the param.
 */
#define UK_LIB_PARAM(name, type)					\
	_LIB_PARAM_NAME_SET(name, _LIB_PARAM_STRING(UK_LIBPARAM_PREFIX,	\
						    name));		\
	_LIB_UK_PARAM_SET(name, type, 1);				\

/**
 * Declare an array of primitive.
 * @param name
 *	The name of the parameter.
 * @param type
 *	The type of the parameter.
 * @param size
 *	The number of element of the argument
 */
#define UK_LIB_PARAM_ARR(name, type, size)				\
	_LIB_PARAM_NAME_SET(name, _LIB_PARAM_STRING(UK_LIBPARAM_PREFIX,	\
						    name));		\
	_LIB_UK_PARAM_SET(name, type, size);				\

/**
 * Declare a string library param.
 * @param name
 *	The name of the parameter.
 * @param max_size
 *	The max length of the string.
 */
#define UK_LIB_PARAM_STR(name, max_size)				\
	UK_LIB_PARAM_ARR(name, char, max_size)

#endif /* __UK_KERNPARAM_H */
