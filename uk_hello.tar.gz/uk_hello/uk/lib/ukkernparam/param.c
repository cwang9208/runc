/* SPDX-License-Identifier: BSD-3-Clause */
/*
 * Authors: Sharan Santhanam <sharan.santhanam@neclab.eu>
 *
 * Copyright (c) 2018, NEC Europe Ltd., NEC Corporation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * THIS HEADER MAY NOT BE EXTRACTED OR MODIFIED IN ANY WAY.
 */
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <uk/list.h>
#include <uk/print.h>
#include <uk/assert.h>
#include <uk/libparam.h>

#define PARAM_MAX_SIZE   (128)
#define ARRAY_SEP	 ' '

struct param_args {
	char param[PARAM_MAX_SIZE];
	__u8 lib_len;
	__u8 param_len;
	__u8 value_len;
};

static UK_TAILQ_HEAD(uk_libsections, struct uk_lib_section) libsections =
			UK_TAILQ_HEAD_INITIALIZER(libsections);

void _uk_kernparam_lib_add(struct uk_lib_section *lib_sec)
{
	UK_TAILQ_INSERT_TAIL(&libsections, lib_sec, next);
}

static void version(void)
{
	printf("Unikraft "
		   STRINGIFY(UK_CODENAME) " "
		   STRINGIFY(UK_FULLVERSION) "\n");
}

static void usage(const char *progname)
{
	printf("Usage: %s\n", progname);
	printf(" [[UNIKRAFT KERNEL ARGUMENT]].. -- [[APPLICATION ARGUMENT]]..\n\n");
	printf("Unikraft library arguments:\n");
	printf("The library arguments are represented as [LIBPARAM_PREFIX].[PARAMNAME]\n\n");
	printf("  -h, --help                 display this help and exit\n");
	printf("  -V, --version              display Unikraft version and exit\n");
}

static inline int kernel_arg_range_fetch(int argc, char **argv)
{
	int i = 0;
	while (i < argc) {
		/* Separate the kernel param from the application parameters */
		if (strcmp("--", argv[i]) == 0) {
			return i;
		}
		i++;
	}

	return -1;
}

static inline int kernel_arg_fetch(const char *progname __maybe_unused,
				   char **args, int nr_args,
				   struct param_args *pargs)
{
	int i = 0;
	int rc = 0;
	char *parameter;
	int len;
	int cnt = 0, index = 0;
	pargs->param_len = 0;
	pargs->value_len = 0;

	for (i = 0; i < nr_args && (!pargs->value_len ||
				    !pargs->param_len); i++) {
		len = strlen(args[i]);
		parameter = strchr(args[i], '=');
		if (strcmp(args[i], "-h") == 0 ||
		    strcmp(args[i], "--help") == 0) {
			usage(progname);
			ukplat_halt();
		} else if (strcmp(args[i], "-V") == 0 ||
			   strcmp(args[i], "--version") == 0) {
			version();
			ukplat_halt();
		} else if (parameter &&
		    (parameter - args[i]) == (len - 1)) {
			/* [libname_prefix].[parameter]= value */
			if (pargs->param_len &&
				strcmp(args[i],"=") == 0) {
				pargs->param[index] = '=';
				index++;
			} else if (pargs->param_len) {
				uk_pr_err("Invalid char (=) in parameter: %s",
					  args[i]);
				rc = -EINVAL;
				goto error_exit;
			} else {
				uk_pr_info("Expecting Parameter %s\n", args[i]);
				pargs->param_len = len - 1;
				memcpy(&pargs->param[index], args[i], len);
				index = len;
			}
			cnt++;
		} else if (parameter &&
			   (parameter - args[i]) < (len - 1)) {
			uk_pr_info("Expecting Entire Argument%s\n", args[i]);
			if (!pargs->param_len) {
				/* [libname_prefix].[parameter]=value */
				pargs->param_len = parameter - args[i];
				pargs->value_len = len - (pargs->param_len + 1);
				memcpy(&pargs->param[index], args[i], len);
			} else {
				/* [libname_prefix].[parameter] =value */
				memcpy(&pargs->param[index], args[i], len);
				pargs->value_len = len - 1;
			}
			index += len;
			cnt++;
		} else if (!parameter) {
			/* [libname_prefix].[parameter] = value */
			if (!pargs->param_len) {
				uk_pr_info("Expecting Parameter Only %s\n",
						args[i]);
				memcpy(&pargs->param[index], args[i], len);
				pargs->param_len = len;
				index += len;
			}
			else if (pargs->param_len &&
				 strcmp(args[i], "=") == 0) {
				uk_pr_info("Expecting == %s\n", args[i]);
				pargs->param[index] = '=';
				index++;
			}
			else if	(pargs->param_len) {
				uk_pr_info("Expecting Value Only %s\n", args[i]);
				pargs->value_len = len;
				memcpy(&pargs->param[index],
				       args[i], len);
				index += len;
			}
			cnt++;
		} else {
			uk_pr_err("Failed to parse the argument:%s\n", args[i]);
			rc = -EINVAL;
			goto error_exit;
		}
		pargs->param[index] = '\0';
	}

	if (pargs->param_len != 0 && pargs->value_len == 0) {
		uk_pr_err("No Value provided for arg: %s\n", pargs->param);
		rc = -EINVAL;
		goto error_exit;
	}

	return cnt;

error_exit:
	return rc;
}

/**
 * Kernel Parameter are passed in this format
 * [libname_prefix].[parameter] =
 */
static inline int kernel_lib_fetch(struct param_args *pargs,
				   struct uk_lib_section **section)
{
	char *libparam = NULL;
	int rc = -EINVAL;
	struct uk_lib_section *iter;

	UK_ASSERT(section);
	pargs->lib_len = 0;

	libparam = memchr(pargs->param, '.', pargs->param_len);
	if (!libparam) {
		uk_pr_err("Failed to identify the library\n");
		rc = -EINVAL;
		goto error_exit;
	}

	UK_TAILQ_FOREACH(iter, &libsections, next) {
		uk_pr_debug("Lib: %s, libname: %s %ld\n", iter->lib_name,
				pargs->param, libparam - pargs->param);
		if (strncmp(pargs->param, iter->lib_name,
			    libparam - pargs->param) == 0) {
			*section = iter;
			pargs->lib_len = libparam - pargs->param;
			return 0;
		}
	}

error_exit:
	uk_pr_err("Failed to fetch the library\n");
	*section = NULL;
	return rc;
}

static inline int kernel_parse_arg(struct param_args *pargs,
				   struct uk_lib_section *section,
				   struct uk_param **param)
{
	int rc = -EINVAL;
	int i = 0;
	struct uk_param *iter = NULL;
	int len = 0;

	UK_ASSERT(section && param);

	len = section->len / sizeof(struct uk_param);
	iter = section->sec_addr_start;
	uk_pr_info("Section length %d\n", len);

	for (i = 0; i < len; i++, iter++) {
		uk_pr_info("%s -- %s \n", iter->name,
				&pargs->param[0]);
		if (memcmp(iter->name,
			   pargs->param, strlen(iter->name)) == 0) {
			*param = iter;
			return 0;
		}
	}

	*param = NULL;
	return rc;
}

static inline int kernel_arg_set(void *addr, char *value, int size, int sign)
{
	switch(size) {
	case 1:
		if (sign)
			*((__s8 *)addr) = *value;
		else
			*((__u8 *)addr) = (__u8)(*value);

		break;
	case 2:
		if (sign)
			*((__s16 *)addr) = (__s16) strtol(value, NULL, 10);
		else
			*((__u16 *)addr) = (__u16) strtoul(value, NULL, 10);
		break;
	case 4:
		if (sign)
			*((__s32 *)addr) = (__s32) strtol(value, NULL, 10);
		else
			*((__u32 *)addr) = (__u32) strtoul(value, NULL, 10);
		break;
	case 8:
		if (sign)
			*((__s64 *)addr) = (__s64) strtoll(value, NULL, 10);
		else
			*((__u64 *)addr) = (__u64) strtoull(value, NULL, 10);
		break;
	default:
		uk_pr_err("Cannot understand type of size %d\n", size);
		return -EINVAL;
		break;

	}
	return 0;
}

static inline int kernel_args_set(struct param_args *pargs,
				  struct uk_param *param)
{
	int rc = 0;
	int len;
	int i  = 0;
	int sign = (param->param_type >> PARAM_SIGN_SHIFT) & PARAM_SIGN_MASK;
	int param_type = (param->param_type >> PARAM_SIZE_SHIFT)
				& PARAM_SIZE_MASK;
	if (sign && param_type == 1) {
		len = MIN(pargs->value_len, (param->param_size - 1));
		/* Processing a string or a char */
		for (i = 0; i < len; i++) {
			rc = kernel_arg_set((void *)(param->addr + i),
					    &pargs->param[pargs->param_len + 1
							  + i],
					    param_type,
					    sign);
			if (rc < 0)
				return rc;
		}
		if (param->param_size > 1)
			*(__s8 *)(param->addr + len) = '\0';
	} else if (param->param_size > 1) {
		/* Comma separated list of parameter */
		char *value = &pargs->param[pargs->param_len + 1];
		i = 0;
		uk_pr_debug("%s args in array \n", value);
		while (value && i < param->param_size) {
			char *start = value;
			value = strchr(value, ARRAY_SEP);
			if (value) {
				*value = '\0';
				/* Search from the next index */
				value++;
			}
			uk_pr_debug("Array index: %d %s\n", i, start);
			rc = kernel_arg_set((void *)(param->addr +
						     (i * param_type)),
					    start, param_type, sign);
			i++;
		}

	} else {
		/* Single parameter */
		rc = kernel_arg_set((void *)param->addr,
				    &pargs->param[pargs->param_len + 1],
				    param_type, sign);
	}

	return rc;
}

int uk_kernparam_parse(const char *progname, int argc, char **argv)
{
	int keindex = 0;
	int rc = 0, cnt = 0;
	struct param_args pargs = {0};
	struct uk_lib_section *section = NULL;
	struct uk_param *param = NULL;

	keindex = kernel_arg_range_fetch(argc, argv);
	if (keindex <= 0) {
		uk_pr_info("No kernel argument found\n");
		return 0;
	}

	uk_pr_debug("kernel argument end %d\n", keindex);

	while(cnt < keindex) {
		/* Fetch the argument from the input */
		rc = kernel_arg_fetch(progname, &argv[cnt], keindex, &pargs);

		if (rc < 0)
			return rc;
		uk_pr_info("kernel argument %s\n", pargs.param);
		cnt += rc;

		/* Fetch library for the argument */
		rc = kernel_lib_fetch(&pargs, &section);
		if (rc < 0 || !section) {
			return rc;
		}

		/* Fetch the parameter for the argument */
		rc = kernel_parse_arg(&pargs, section, &param);
		if (rc < 0 || !param) {
			uk_pr_info("Failed to parse arg\n");
			return rc;
		}
		rc = kernel_args_set(&pargs, param);
		uk_pr_info("Parsed %d args\n", cnt);
	}

	/* Replacing the -- with progname */
	argv[keindex] = DECONST(char *, progname);

	return keindex;
}
