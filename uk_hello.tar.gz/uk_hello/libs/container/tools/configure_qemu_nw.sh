#!/bin/bash
#
#  Authors: Sharan Santhanam <sharan.santhanam@neclab.eu>
#
#  Copyright (c) 2018, NEC Europe Ltd., NEC Corporation. All rights reserved.
#
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions
#  are met:
#
#  1. Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.
#  2. Redistributions in binary form must reproduce the above copyright
#     notice, this list of conditions and the following disclaimer in the
#     documentation and/or other materials provided with the distribution.
#  3. Neither the name of the copyright holder nor the names of its
#     contributors may be used to endorse or promote products derived from
#     this software without specific prior written permission.
#
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
#  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
#  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
#  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
#  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
#  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
#  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
#  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
#  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
#  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
#  POSSIBILITY OF SUCH DAMAGE.
#
################################################################################
filename=$(basename $0)
nw_location=/etc/network/interfaces

print_usage() {
echo "${filename} [-c nr_ifs] <-I eth_if> [-f config_file] <-n nw_namespace> "\
	 "<-r rootfs> [-g]"
}


## Fetch information from the configuration file
## fetch_nw_info ${config_file} ${if} ${info_type}
fetch_nw_info() {
	info=$(cat ${1} | grep ${2} | grep ${3})
	[[ $? -ne 0 ]] && { return 1; }
	echo $(echo ${info} | cut -d ':' -f 2)
	return 0;
}

## Fetch the next ip address
## ip_next_get ${ip_addr} ${mask}
ip_next_get() { 
	local index=4;
	local min_index=$((4 - ( mask / 8 ) ))
	local ip=""

	while [ ${index} -ge ${min_index} ]; do
		octet=$(echo ${1} | cut -d '.' -f ${index})		
		if [ ${octet} -lt 254 ]; then
			octet=$((octet + 1))
			ip=$(echo ${1} | cut -d '.' -f 1-$((index - 1)) )
			ip=${ip}.${octet}
			last_part=$(echo ${1} | cut -d '.' -f $((index + 1))-4 2>/dev/null )
			if [ $? -eq 0 ] && [ ! -z ${last_part} ]; then
				ip=${ip}.${last_part}
			fi
			break;
		fi
		index=$((index - 1))
	done;
	[[ -z ${ip} ]] && { return 1; }

	echo ${ip}
	return 0;
}

## Fetch the tap ip address
## tap_ip_fetch ${config_file} ${eth_if}
tap_ip_fetch() {
	local ip_addr="";
	ip_addr=$(fetch_nw_info ${1} ${2} ip)
	[[ $? -ne 0 ]] && return 1;

	ip=$(echo ${ip_addr} | cut -d '/' -f 1)
	mask=$(echo ${ip_addr} | cut -d '/' -f 2)

	tap_ip=$(ip_next_get ${ip} ${mask})
	[[ $? -ne 0 ]] && { echo "Failed in next ip"; return 1; }
	echo ${tap_ip}/${mask}

	return 0;
}

## Create a tap device
## create_tap_dev ${dev} ${nw_ns} ${ip_address}
create_tap_dev() {
	## Creating a tap device for the root user as we currently support only root
	## with root user.
	ip netns exec ${2} ip tuntap add dev tap-${1} mode tap
	ip netns exec ${2} ip addr add ${3} dev tap-${1}
}


## Add a tap device network configuration.
## create_tap_dev ${dev} ${ip_address} ${rootfs_base} ${gatewayip}
add_tap_dev_config() {
	local nw_file=${3}${nw_location}

	[[ ! -d $(dirname ${nw_file}) ]] && mkdir -p $(dirname ${nw_file})

	echo "" >> ${nw_file}
	echo "iface tap-${1} inet static" >> ${nw_file}
	echo "		address ${2}" >> ${nw_file}
	[[ ! -z ${4} ]] && { echo "		gateway ${4}" >> ${nw_file}; }
}
echo test

gateway=0

while getopts c:I:f:n:r:gh opt; do
	case $opt in
	c)
		nw_ifs=${OPTARG}
	;;
	f)
		config_file=${OPTARG}
	;;
	I)
		eth_ifs=${OPTARG}
	;;
	n)
		nw_ns=${OPTARG}
	;;
	g)
		gateway=1
	;;
	r)
		rootfs_path=${OPTARG}
		[[ ! -d ${rootfs_path} ]] && { \
				echo "Invalid rootfs path ${rootfs_path}"; print_usage; exit 1; }
	;;
	h)
		print_usage
		exit
	;;
	esac
done

[[ ! -z ${eth_ifs} ]] || { echo "Empty interface list"; print_usage; exit 1; }

[[ ! -z ${nw_ifs} ]] || { nw_ifs= 1; }

eth_ifs_cnt=$(echo ${eth_ifs} | awk -F"," '{print NF}')
[[ ${eth_ifs_cnt} != ${nw_ifs} ]] && \
	{ echo "Invalid user input"; print_usage; exit 1; }


[[ ! -z ${rootfs_path} ]] && [[ -d ${rootfs_path} ]]  || \
		{ echo "Invalid rootfs path"; print_usage; exit 1; }

[[ ! -z ${config_file} ]] || { config_file=.ip; }
ip_config_file=${rootfs_path}/${config_file}

eth_ip_cnt=$(cat ${ip_config_file} | grep ip | wc -l)
[[ ${eth_if_cnt} -eq ${eth_ifs} ]] || { echo "Invalid configuration setup"; exit 1; }

for eth_if in $(echo ${eth_ifs} | tr "," " "); do
	eth_if=g-${eth_if}
	ip_addr=$(tap_ip_fetch ${rootfs_path}/${config_file} ${eth_if})
	[[ $? -ne 0 ]] && { echo "Cannot find a tap ip"; exit 1; }
	if [ ${gateway} -eq 1 ]; then
			route_ip=$(fetch_nw_info ${rootfs_path}/${config_file} ${eth_if} gateway); 
			[[ $? -ne 0 ]] && { echo "Invalid gateway configuration."; exit 1; }
	fi

	create_tap_dev ${eth_if} ${nw_ns} ${ip_addr}
	if [ ${gateway} -eq 1 ]; then
		add_tap_dev_config ${eth_if} ${ip_addr} ${rootfs_path} ${route_ip}
	else
		add_tap_dev_config ${eth_if} ${ip_addr} ${rootfs_path}
fi
done
