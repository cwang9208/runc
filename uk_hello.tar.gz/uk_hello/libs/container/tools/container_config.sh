#!/bin/bash
#
#  Authors: Sharan Santhanam <sharan.santhanam@neclab.eu>
#
#  Copyright (c) 2018, NEC Europe Ltd., NEC Corporation. All rights reserved.
#
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions
#  are met:
#
#  1. Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.
#  2. Redistributions in binary form must reproduce the above copyright
#     notice, this list of conditions and the following disclaimer in the
#     documentation and/or other materials provided with the distribution.
#  3. Neither the name of the copyright holder nor the names of its
#     contributors may be used to endorse or promote products derived from
#     this software without specific prior written permission.
#
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
#  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
#  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
#  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
#  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
#  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
#  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
#  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
#  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
#  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
#  POSSIBILITY OF SUCH DAMAGE.
#
################################################################################
execName=$(basename ${0})

printUsage() {
	echo "${execName} <-e program> <-w workspace> <-i inputfile> " \
		"<-p rootfs_path> <-o outputfile> [-s syscall] [-a args] "
}

formatArgs() {
	args=""
	for arg in $@; do
		args=$([[ ! -z ${args} ]] && echo -n ${args}",")
		args="${args}\"${arg}\""	
	done
	echo ${args}
}

formatSyscalls() {
	if [ ! -f ${1} ]; then
		echo "${1} file was not found"
		return 1;
	fi
	while read LINE;
	do
		if [ -z ${LINE} ]; then
			continue
		fi;
		SYSCALL=$([[ ! -z ${SYSCALL} ]] && echo -n ${SYSCALL}",")
		SYSCALL="${SYSCALL}\"${LINE}\""
	done < ${1}
	echo ${SYSCALL}
}

fixArgs() {
	sed -i 's:"@UK_ARGS@":'${2}':' ${1}
}

fixRootfsPath() {
	sed -i 's:"@UK_ROOTFS_PATH@":'${2}':' ${1}
}

UK_SYSCALL_F=""
while getopts i:o:a:s:p:w:e:h opt
do
	case $opt in
	a)
		UK_ARGS="${OPTARG}"
	;;
	e)
		UK_EXEC="${OPTARG}"
	;;
	s)
		UK_SYSCALL_F=${OPTARG}
	;;
	i)
		UK_CONF_IF="${OPTARG}"
	;;
	o)
		UK_CONF_OF="${OPTARG}"
		echo ${UK_CONF_OF}
	;;
	p)
		UK_ROOTFS_PATH="${OPTARG}"
	;;
	w)
		WORKSPACE="${OPTARG}"
	;;
	h)
		printUsage
		exit 0
	;;
	esac
done

echo exec:${UK_EXEC}

[[ ! -z "${WORKSPACE}" ]] || { echo "Invalid workspace"; printUsage; exit 1; }

pushd ${WORKSPACE}

## Check if the rootfs path was created.
( [[ ! -z "${UK_ROOTFS_PATH}" ]] && [[ -d "${UK_ROOTFS_PATH}" ]] ) || \
		{ echo "Invalid rootfs path"; printUsage; exit 1; }

## Validating the executable
( [[ ! -z "${UK_EXEC}" ]] && [[ -f ${UK_ROOTFS_PATH}/${UK_EXEC} ]] ) ||\
		{ echo "Cannot find the executable"; printUsage; exit 1; }

## Check for the config template.
( [[ ! -z "${UK_CONF_IF}" ]] && [[ -f "${UK_CONF_IF}" ]] ) ||\
		{ echo "Invalid configuration file"; printUsage; exit 1; }

## Check for the output directory
( [[ ! -z "${UK_CONF_OF}" ]] && [[ -d $(dirname \
		"${UK_CONF_OF}") ]] ) ||\
		{ echo "Invalid output configuration file"; printUsage; exit 1; }


OUTPUT_FILE=${UK_CONF_OF}/config.json
cp ${UK_CONF_IF} ${OUTPUT_FILE}

ARGS=$(formatArgs ${UK_EXEC} "${UK_ARGS}")

if [ ! -z ${UK_SYSCALL_F} ]; then
	SYSCALLS=$(formatSyscalls ${UK_SYSCALL_F})
fi

fixArgs ${OUTPUT_FILE} "${ARGS}"
fixRootfsPath ${OUTPUT_FILE} "\"${UK_ROOTFS_PATH}\""

popd
