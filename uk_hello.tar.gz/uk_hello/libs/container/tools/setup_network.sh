#!/bin/bash -x
#
#  Authors: Sharan Santhanam <sharan.santhanam@neclab.eu>
#
#  Copyright (c) 2018, NEC Europe Ltd., NEC Corporation. All rights reserved.
#
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions
#  are met:
#
#  1. Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.
#  2. Redistributions in binary form must reproduce the above copyright
#     notice, this list of conditions and the following disclaimer in the
#     documentation and/or other materials provided with the distribution.
#  3. Neither the name of the copyright holder nor the names of its
#     contributors may be used to endorse or promote products derived from
#     this software without specific prior written permission.
#
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
#  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
#  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
#  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
#  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
#  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
#  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
#  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
#  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
#  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
#  POSSIBILITY OF SUCH DAMAGE.
#
################################################################################
################################################################
#  Script to create a bridged network in the runc environment
################################################################
fileName=$(basename $0)
print_usage() {
	echo "${fileName} <-o operation> <-B bridgeName> [-b bridgeIp] <-I ifName> 
"\
	"<-n nsName> <-i ipaddressRange> <-r rootfs_path> [-g enablegw]"
}

## Validate if the ip format is in CIDR format.
## validate_ip_fmt ${ip_addr}
validate_ip_fmt() {
	local ip_addr=$1
	
	## CIDR representation.
	## Check for ip format <ip_addr>/<mask>.
	nf=$(echo ${ip_addr} | awk -F '/' '{print NF}')
	[[ ${nf} -ne 2 ]] && { echo "Wrong ip format ${nf}"; print_usage; return 1; }

	nf=$(echo ${ip_addr} | awk -F '/' '{print $1}' | awk -F '.' '{print NF}')
	[[ ${nf} -ne 4 ]] && { echo "Wrong ip format"; return 1; }

	return 0;
}

## Get the ip mask for the given ip_address range. The ip address should be in
## CIDR format.
## ip_mask_get ${ip_addr}
ip_mask_get() {
	local mask="";
	local ip="";
	local ip_addr="";
	local ip_mask=0;
	local i=0;
	local ip_seg="";

	## Fetch the mask and the ip address from CIDR.
    mask=$(echo $1 | awk -F'/' '{print $2}')
    [[ -z ${mask} ]] && return 1;
    ip=$(echo $1 | awk -F'/' '{print $1}')

    ip_mask=$((32 - ${mask}))
    i=4;

    while [ $i -ne 0 ]; do
        [[ ! -z ${ip_addr} ]] && { ip_addr=.${ip_addr}; }
		
        if [ ${ip_mask} -ge 8 ]; then
			## Add zero mask is >= 8. Masking the entire octet.
            ip_addr=0${ip_addr}
            ip_mask=$((ip_mask - 8))
        else

            ip_seg=$(echo ${ip} | cut -d '.' -f ${i})

            if [ ${ip_mask} -gt 0 ]; then
				## Masking out the partial part of the octet.
                mask=$(( (1 << ip_mask) -1 ))
                ip_seg=$((ip_seg & ~(mask) ))
                ip_mask=0
            fi;

            ip_addr=${ip_seg}${ip_addr}
        fi;
        i=$((i - 1))
    done

	echo ${ip_addr};
    return 0;
}

## Get the list of ip address range valid
## ip_addr_range ${ip_addr} ${ip_mask}
ip_addr_range() {
	local ip_addr=${1}
	local ip_mask=${2}
	local i=0
	local ip_end_range=""
	local ip_start_range=""
	local mask=0

	ip_start_range=$(ip_mask_get ${ip_addr}/${ip_mask})
	[[ $? -ne 0 ]] && return 1;

	i=$((ip_mask / 8))
	if [ $i -gt 0 ]; then
		ip_end_range=$(echo ${ip_start_range} | cut -d '.' -f 1-$i);
	else
		ip_end_range=""
	fi;

	mask=${ip_mask}
	while [ $i -lt 4 ]; do
		i=$((i + 1))
		rem=$((8 - (mask % 8)))
		mask=$((mask + rem))
		ip_seg=$(echo ${ip_start_range} | cut -d '.' -f ${i})
		ip_seg=$((ip_seg | ( ( (1 << rem) - 1) & 0xFF) ))
		[[ $i -ne 1 ]] && { ip_end_range=${ip_end_range}.; }
		ip_end_range=${ip_end_range}${ip_seg}
	done
	echo ${ip_start_range},${ip_end_range}

	return 0;
}

## Create a bridge interface.
## create_bridge ${bridge_if} ${bridge_ip} ${gw_flag}
create_bridge() {
	local bridge_if=${1}
	local bridge_ip=${2}
	local gw_flag=${3}

	ip link add name ${bridge_if} type bridge
	ip link set ${bridge_if} up;
	ip addr add ${bridge_ip} dev ${bridge_if};

	if [ $# -eq 3 -a ${gw_flag} -eq 1 ]; then
		ip_mask=$(ip_mask_get ${bridge_ip})
		[[ $? -ne 0 ]] && { echo "Failed to create bridge"; return 1; }
		ip_mask=${ip_mask}/$(echo ${bridge_ip} | cut -d '/' -f 2)
		config_ip_table ${bridge_if} ${ip_mask}
	fi;
	return 0;
}

sys_gw_get() {
local gw="";
	gw=$(ip route show | grep default |head -n 1 \
			| awk '{\
						   for(i = 1;i < NF; i++) {\
								if ($i == "dev") {\
									print $(i + 1); break;\
								}\
							}\
					}')
	[[ -z ${gw} ]] && { echo "Cannot find a gateway"; return 1; }
	echo ${gw}

	return 0;
}

## config_ip_table ${bridge-if} ${address-range}
config_ip_table() {
	local gw="";
	local ifname=$1;
	local ipaddr=$2;

	gw=$(sys_gw_get) && ret=1;
	[[ $? -ne 0 ]] && { return 1; }

	iptables -t nat -A POSTROUTING -s ${ipaddr} -o ${gw} -j MASQUERADE
	iptables -A FORWARD -i ${ifname} -o ${gw} -j ACCEPT
	iptables -A FORWARD -i ${gw} -o ${ifname} \
				-m state --state ESTABLISHED,RELATED -j ACCEPT
	return 0;
}

## Remove the rule added to the iptables.
restore_ip_table() {
	local gw = "";
	local ifname=$1;
	local ipaddr=$2;

	gw=$(sys_gw_get)
	[[ $? -ne 0 ]] && return 1;

	iptables -t nat -D POSTROUTING -s ${ipaddr} -o ${gw} -j MASQUERADE
	iptables -D FORWARD -i ${ifname} -o ${gw} -j ACCEPT
	iptables -D FORWARD -i ${gw} -o ${ifname} \
			-m state --state ESTABLISHED,RELATED -j ACCEPT
	return 0;
}

bridge_addr_get() {
	local bridge_if=${1};
	local ret="";
	local ip="";

	ret=$(ip link show type bridge | grep -i ${bridge_if})
	[[ -z ${ret} ]] && { return 1; }

	## Fetch the ip address.
	ip=$(ip -4 addr show ${bridge_if} 2>/dev/null | grep inet | awk '{print $2}')
	[[ -z ${ip} ]] && { return 1; }

	echo ${ip};
	return 0;
}

bridge_ip_addr_match() {
	local bridge_ip=$(echo ${1} | cut -d '/' -f 1)
	local ip=$(echo ${2} | cut -d '/' -f 1)
	local bridge_mask=$(echo ${1} | cut -d '/' -f 2)
	local ip_mask=$(echo ${2} | cut -d '/' -f 2)

	## Get the valid ip address range of the bridge.
	bridge_range=$(ip_addr_range ${bridge_ip} ${bridge_mask})
	[[ $? -ne 0 ]] && return 1;
	bridge_start=$(echo ${bridge_range} | cut -d ',' -f 1)
	bridge_end=$(echo ${bridge_range} | cut -d ',' -f 2)

	i=0
	while [ $i -lt 4 ]; do
		i=$((i + 1))
		ip_seg=$(echo ${ip} | cut -d '.' -f ${i})
		br_sseg=$(echo ${bridge_start} | cut -d '.' -f ${i})
		br_eseg=$(echo ${bridge_end} | cut -d '.' -f ${i})

		if [ ${ip_seg} -lt ${br_sseg} -o ${ip_seg} -gt ${br_eseg} ]; then
			return 1;
		fi
	done 

	return 0;
}

check_bridge_if() {
local bridge_if=${1}
local bridge_ip=""
ret=0;
bridge_ip=$(bridge_addr_get ${bridge_if}) || ret=1;
return ${ret}
}

## Prepare the bridge interface.
## prepare_bridge ${bridge_if} ${if_cnt} ${ip_addr} ${enable_gw} ${bridge_ip}
prepare_bridge() {
local bridge_prefix=${1}
local if_cnt=${2}
local ip_addrs=${3}
local gw_flag=${4}
local bridge_ip=${5}
ret=0

if [ -z ${bridge_ip} ]; then
	## Get the ip address of the bridge.
	bridge_ip=$(bridge_addr_get ${bridge_prefix}) || ret=1;
else 
	## Create the bridge interface.
	create_bridge ${bridge_prefix} ${bridge_ip} ${gw_flag};
	[[ $? -ne 0 ]] && { return 1; }
fi

## Verify if the subnet range of the user address is within
## bridge address range.
for ip in $(echo ${ip_addrs} | tr ',' ' '); do
	bridge_ip_addr_match ${bridge_ip} ${ip}
	[[ $? -ne 0 ]] && { return 1; }
done;
echo ${bridge_ip}
return 0;
}

## Adding the network configuration for the container environment
## add_nw_config ${guestif} ${ip_addr} ${route_ip} ${rootfs_path}
add_nw_config() {
	local if=${1}
	local ip=${2}
	local gw=${3}
	local rootfs=${4}
	local nw_cfg_name=".ip"
	local nw_cfg_file=${rootfs}/${nw_cfg_name}

	[[ ! -f ${nw_cfg_file} ]] && { touch ${nw_cfg_file}; }
	
	echo "ip[${if}]:${ip_addr}" >> ${nw_cfg_file}
	echo "gateway[${if}]:${gw}" >> ${nw_cfg_file}
}

## Create the veth pairs.
## create_veth ${bridgename} ${host-interface} ${guest-interface} ${namespace}
##             ${bridge-ip} ${remote-ip}
create_veth() {
	## Creating virtual ethernet pairs.
	ip link add name ${2} type veth peer name ${3}
	ip link set ${2} up

	## Adding the host interface to the bridge
	ip link set ${2} master ${1}


	## Adding the guest interface to the namespace
	ip link set dev ${3} netns ${4}

	## Bringup the container network interface
	ip netns exec ${4} ip addr add ${6} dev ${3}
	ip netns exec ${4} ip link set ${3} up
	ip netns exec ${4} ip route add default via ${5}
}

## Create the veth pairs.
## create_veth ${pid} ${bridge_if} ${nr_ifs} ${ifs} ${namespace} ${route-ip} ${remote-ip}
create_veths() {
	local pid=${1}
	local bridge_if=${2}
	local nr_ifs=${3}
	local ifs=${4}
	local nw_ns=${5}
	local route_ip=${6}
	local remote_ip=${7}
	local rootfs_path=${8}
	local nw_cfg_name=".ip"
	local nw_cfg_file=${rootfs}/${nw_cfg_name}

	[[ -f ${nw_cfg_file} ]] && { rm ${nw_cfg_file}; }

	## Creating a network namespace for the container.
	ip netns add ${nw_ns}
	mount -o bind /proc/${pid}/ns/net /var/run/netns/${nw_ns}
	ret=$?
	[[ $ret -ne 0 ]] && { echo "Mount failed $ret"; exit 1; }

	for i in $(seq 1 ${nr_ifs}); do
		local ip_addr=$(echo ${remote_ip} | cut -d ',' -f ${i})
		local if=$(echo ${ifs} | cut -d ',' -f ${i})
		echo ${bridge_if} h-${if} g-${if} ${nw_ns} ${route_ip} ${ip_addr}
		create_veth ${bridge_if} h-${if} g-${if} ${nw_ns} ${route_ip} ${ip_addr}
		add_nw_config g-${if} ${ip_addr} ${route_ip} ${rootfs_path}
	done;
}

## Delete the veth pairs.
## delete_veth ${bridge_if} ${host-if} ${guest_if} ${namespace}
delete_veth() {
	local bridge_if=${1}
	local host_if=${2}
	local guest_if=${3}
	local namespc=${4}

	## Stop the host interface.
	ip netns exec ${namespc} ip link set eth1 down
	ip link set ${1} down

	## Removing the host interface from the bridge
	ip link set ${2} down
	ip link set ${2} nomaster

	## Removing the remote interface.
	ip netns exec ${4} ip link del eth1

}

delete_veths() {
	local pid=${1}
	local bridge_if=${2}
	local nr_ifs=${3}
	local ifs=${4}
	local nw_ns=${5}

	for i in $(seq 1 ${nr_ifs}); do
		local ip_addr=$(echo ${remote_ip} | cut -d ',' -f ${i})
		local if=$(echo ${ifs} | cut -d ',' -f ${i})
		delete_veth ${bridge_if} h-${if} g-${if} ${nw_ns}
	done
	umount /proc/${pid}/ns/net

	## Delete the namespace
	ip netns del ${nw_ns}
}

val=$(cat)
i=0
pid=$(echo ${val} | awk -F"," '{print $4}' | awk -F":" '{print $2}' | cut -d '/' -f 1);
[[ -d /proc/${pid} ]] || { echo "Cannot find the process id ${pid}"; exit 1; }

while getopts c:o:B:b:I:i:n:r:gh opt
do
	case $opt in
	c)
		nr_ifs=${OPTARG}
	;;
	o)
		op="${OPTARG}"
	;;
	B)
		bridge_if="${OPTARG}"
	;;
	b)
		bridge_ip="${OPTARG}"
		validate_ip_fmt ${bridge_ip}
		[[ $? -ne 0 ]] && { print_usage; exit 1; }
	;;
	I)
		ifs="${OPTARG}"
	;;
	i)
		ip_addr="${OPTARG}"
		for ip in $(echo ${ip_addr} | tr ',' ' '); do
			validate_ip_fmt ${ip}
			[[ $? -ne 0 ]] && { print_usage; exit 1; }
		done;
	;;
	n)
		ns="${OPTARG}"
	;;
	g)
		gw_flag=1
	;;
	h)
		print_usage;
		exit 0;
	;;
	r)
		rootfs_path=${OPTARG}
		[[ ! -d ${rootfs_path} ]] && { echo "Invalid rootfs path ${rootfs_path}"; \
										print_usage; exit 1; }
	;;
	*)
		echo "Invalid argument";
		print_usage;
		exit 1;
	;;
	esac
done

[[ ! -z ${nr_ifs} ]] || { nr_ifs=1; }

## Validating the input parameter
ip_cnt=$(echo ${ip_addr} | awk -F"," '{print NF}')
if_cnt=$(echo ${ifs} | awk -F"," '{print NF}')

[[ ${ip_cnt} -eq ${nr_ifs} ]] && [[ ${if_cnt} -eq ${nr_ifs} ]] ||\
		{ printf " Nr of Ifs: %d, IP Count %d, IF Name Count %d\n"\
				 ${nr_ifs} ${ip_cnt} ${if_cnt}; exit 1; }

[[ ! -z ${op} ]] || { echo "operation cannot be empty"; \
								print_usage; exit 1; }

[[ ! -z ${ns} ]] || { echo "Namespace missing"; \
										print_usage; exit 1; }

[[ ! -z ${bridge_if} ]] || { echo "bridge interface not defined"; exit 1; }

## Bridge ip is given then we bridge interface should not exist.
if [ ! -z ${bridge_ip} ]; then
	check_bridge_if ${bridge_if}
	[[ $? -eq 0 ]] && { \
		 echo "Bridge interface ${bridge_if} is already configured"; exit 1; }
	echo "Bridge IP ${bridge_ip}"
else
	bridge_ip=""
fi

[[ ! -z ${if_prefix} ]] || { if_prefix=veth; }

if [ ${op} == "create" ]; then
[[ ! -z ${rootfs_path} ]] || { \
				echo "Invalid rootfs configuration ${rootfs_path}"; exit 1; }
[[ ! -f /var/run/netns/${namespace_prefix} ]] || { echo "Namespace exists"; \
										print_usage; exit 1; }
elif [ ${op} == "delete" ]; then
[[ -f /var/run/netns/${ns} ]] || { \
					echo "Namespace does not exists"; print_usage; exit 1; }
fi

if [ -z ${gw_flag} ]; then
gw_flag=0
fi

if [ ${op} == "create" ]; then
	echo " ${bridge_if} ${nr_ifs} ${ip_addr} ${gw_flag} ${bridge_ip}"
	bridge_ip=$(prepare_bridge ${bridge_if} ${nr_ifs} ${ip_addr}\
								 ${gw_flag} ${bridge_ip})
	[[ $? -ne 0 ]] && { echo "Failed to create a bridge"; exit 1; }

	route_ip=$(echo ${bridge_ip} | cut -d '/' -f 1)
	create_veths ${pid} ${bridge_if} ${nr_ifs} ${ifs} ${ns} ${route_ip} ${ip_addr} \
				 ${rootfs_path}

elif [ ${op} == "delete" ]; then
	delete_veths ${pid} ${bridge_if} ${nr_ifs} ${ifs} ${ns}
else
	echo "Invalid Operation: $op"
	print_usage
	exit 1
fi
