#!/bin/bash
#
#  Authors: Sharan Santhanam <sharan.santhanam@neclab.eu>
#
#  Copyright (c) 2018, NEC Europe Ltd., NEC Corporation. All rights reserved.
#
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions
#  are met:
#
#  1. Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.
#  2. Redistributions in binary form must reproduce the above copyright
#     notice, this list of conditions and the following disclaimer in the
#     documentation and/or other materials provided with the distribution.
#  3. Neither the name of the copyright holder nor the names of its
#     contributors may be used to endorse or promote products derived from
#     this software without specific prior written permission.
#
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
#  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
#  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
#  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
#  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
#  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
#  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
#  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
#  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
#  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
#  POSSIBILITY OF SUCH DAMAGE.
#
################################################################################
# Creating the rootfs image
EXECNAME=$(basename $0)
ROOTFS_BASE=""


print_usage()
{
	echo "${EXECNAME} <Target Location> <ImageConfig>"
	echo "<Target Location>: The target location for the "\
	"creation of the package"
	echo "<ImageConfig>: The target rootfs image configuration."
}

create_dir()
{
	if [ $# -lt 1 ]
	then
	# File name missing
		return 1;  
	elif [ $# -ge 2 ]
	then
	# Case with file mode being set
		ret=$((mkdir -p ${ROOTFS_BASE}/${1} 2>/dev/null && \
		chmod ${2} ${ROOTFS_BASE}/${1} 2>/dev/null); echo $?)
		shift 2
	else
		ret=$(mkdir -p ${ROOTFS_BASE}/${1} 2>/dev/null; echo $?)
		shift
	fi
	return ${ret}
}

create_file()
{
	if [ $# -lt 1 ]
	then
		return 1;
	elif [ $# -ge 2 ]
	then
		file=${1}
		shift
		mode=${1}
		shift
		ret=$( (touch ${ROOTFS_BASE}/${file} && \
		chmod ${mode} ${ROOTFS_BASE}/${file}); echo $?)
	fi
	return ${ret}
}

create_slink()
{
	if [ $# -lt 2 ]
	then
		return 1;
	else
		target=${2}
		link_target=${ROOTFS_BASE}/${1}
		`[[ -f ${link_target} ]] && { rm ${link_target}; echo $?; }`
		ret=$( [[ -f ${target} ]] && \
			{ ln -s ${target} ${link_target} 2>/dev/null; echo $?; } )
	fi
	return ${ret}
}

copy_file()
{
	if [ $# -lt 2 ]
	then
		return 1;
	else
		src=${2}
		target=${ROOTFS_BASE}/${1}
		echo "SRC: ${2} tar: ${1}"
		ret=$( [[ -f ${src} ]] && \
			 cp -L ${src} ${target} 2>/dev/null; echo $?;)
	fi

	return ${ret}
}

create_rootfs()
{
	while read LINE;
	do
		file_type=$(echo ${LINE} | cut -d ' ' -f 1)
		args=$(echo ${LINE} | cut -d ' ' -f 2-)
		if [ "${file_type}" == "dir" ];then
			echo "Creating dir ${args}"
			create_dir ${args}
			ret=$?
		elif [ "${file_type}" == "file" ]; then
			echo "Creating file ${args}"
			create_file ${args}
			ret=$?
		elif [ "${file_type}" == "slink" ]; then
			echo "Creating link ${args}"
			create_slink ${args}
			ret=$?
		elif [ "${file_type}" == "copy" ]; then
			echo "Creating copy ${args}"
			copy_file ${args}
			ret=$?
		fi
		if [ ${ret} -ne 0 ]; then
			exit 1
		fi
	done < ${IMAGE_CONFIG}
}

if [ $# -ne 2 ]
then
	print_usage
	exit 1;
fi
ROOTFS_BASE=$1
IMAGE_CONFIG=$(readlink -f $2)

echo "Creating the rootfs @${ROOTFS_BASE}"
echo "IMAGE Config ${IMAGE_CONFIG} ${2}"

pushd ${ROOTFS_BASE}
create_rootfs
popd
